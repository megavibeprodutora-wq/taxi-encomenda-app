import React, { useState } from 'react';
import { View, Text, TextInput, Button } from 'react-native';

export default function RegisterScreen({ navigation }) {
  const [username, setUsername] = useState('');

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Registrar</Text>
      <TextInput
        style={{ borderWidth: 1, padding: 8, width: 200, marginBottom: 10 }}
        placeholder="Digite seu nome"
        value={username}
        onChangeText={setUsername}
      />
      <Button title="Registrar" onPress={() => navigation.navigate('Login')} />
    </View>
  );
}